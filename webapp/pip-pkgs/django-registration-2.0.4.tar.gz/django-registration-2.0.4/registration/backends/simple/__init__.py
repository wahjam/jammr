"""
A one-step registration workflow, in which a user signs up and is
immediately active and logged in.

To use, include() the provided URLconf --
registration.backends.simple.urls -- somewhere in your URL
configuration.

For more details, see the documentation in the docs/ directory of the
source-code distribution, or online at
http://django-registration.readthedocs.org/

"""
