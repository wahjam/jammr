"""
Postmarkup
Author: Will McGugan (http://www.willmcgugan.com)

BBCode rendering engine

http://code.google.com/p/postmarkup/

"""

__version__ = "1.2.2"

from parser import *
